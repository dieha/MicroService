package com.redhat.demo.controller;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import javax.management.RuntimeErrorException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.google.gson.JsonObject;

import io.opentracing.Span;

@RestController
@RequestMapping("/")
public class FunctionController {

	@Autowired
	RestTemplate restTemplate;
	@Autowired
	AsnyService asnyService;
	@Value("${rest.url}")
	String fooResourceUrl;
	@Value("${step1.url}")
	String step1;
	@Value("${step2.url}")
	String step2;
	@Value("${step3.url}")
	String step3;

	@RequestMapping(value = "/route", method = RequestMethod.GET)
	public String route(@RequestHeader Map<String, String> headers) throws UnknownHostException, InterruptedException {

		SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");
		Date date1 = new Date();

		System.out.println("STEP--------------------------------------------------");

		headers.forEach((key, value) -> {
			System.out.println(String.format("Header '%s' = %s", key, value));
		});

		System.out.println("Start time:" + format.format(date1));
		System.out.println("My jost Name is :" + InetAddress.getLocalHost().getHostName());

		System.out.println("--------------------------------------------------");
		System.out.println(fooResourceUrl);

		HttpHeaders reqheaders = new HttpHeaders();
		reqheaders.set("end-user", "vip");
		HttpEntity<String> entity = new HttpEntity<String>("parameters", reqheaders);

		ResponseEntity<String> response = restTemplate.getForEntity(fooResourceUrl, String.class);

		return diffTime(format, date1);
	}

	@RequestMapping(value = "/route/url", method = RequestMethod.GET, params = { "url" })
	public String routeTest(@RequestHeader Map<String, String> headers, @RequestParam String url)
			throws UnknownHostException, InterruptedException {

		SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");
		Date date1 = new Date();

		System.out.println("URL--------------------------------------------------");

		headers.forEach((key, value) -> {
			System.out.println(String.format("Header '%s' = %s", key, value));
		});

		System.out.println("Start time:" + format.format(date1));
		System.out.println("My jost Name is :" + InetAddress.getLocalHost().getHostName());

		System.out.println("--------------------------------------------------");

		HttpHeaders reqheaders = new HttpHeaders();
		reqheaders.set("end-user", "vip");
		HttpEntity<String> entity = new HttpEntity<String>("parameters", reqheaders);

		ResponseEntity<String> response = restTemplate.getForEntity(url, String.class);

		return diffTime(format, date1);
	}

	@RequestMapping(value = "/route/step", method = RequestMethod.GET)
	public String routeStep(@RequestHeader Map<String, String> headers)
			throws UnknownHostException, InterruptedException {

		SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");
		Date date1 = new Date();

		System.out.println("STEP--------------------------------------------------");

		headers.forEach((key, value) -> {
			System.out.println(String.format("Header '%s' = %s", key, value));
		});

		System.out.println("Start time:" + format.format(date1));
		System.out.println("My jost Name is :" + InetAddress.getLocalHost().getHostName());

		System.out.println("--------------------------------------------------");

		HttpHeaders reqheaders = new HttpHeaders();
		reqheaders.set("end-user", "vip");
		reqheaders.setContentType(MediaType.APPLICATION_JSON);

		asnyService.callHttp();
		ResponseEntity<String> response1 = restTemplate.getForEntity(step1, String.class);
		JsonObject personJsonObject = new JsonObject();
		personJsonObject.addProperty("name", response1.getBody());
		HttpEntity<String> entity = new HttpEntity<String>(personJsonObject.toString(), reqheaders);
		ResponseEntity<String> response2 = restTemplate.postForEntity(step2, entity, String.class);
		ResponseEntity<String> response3 = restTemplate.getForEntity(step3, String.class);
		System.out.println("---Final get---" + response3.getBody());
		return diffTime(format, date1);
	}

	public String diffTime(SimpleDateFormat format, Date date1) {

		Date date2 = new Date();
		System.out.println("End time:" + format.format(date2));
		Long difference = date2.getTime() - date1.getTime();

		return difference.toString() + "ms";

	}

	@RequestMapping(value = "/error", method = RequestMethod.GET)
	public String getError() throws SQLException {

		throw new SQLException("my fault");
	}
	

	@RequestMapping(value = "/errors", method = RequestMethod.GET)
	public String getErrors() {

		throw new RuntimeException();
	}

	public static long fib(int n) {
		if (n == 1)
			return 1;
		else if (n == 2)
			return 1;
		else
			return fib(n - 1) + fib(n - 2);
	}

}

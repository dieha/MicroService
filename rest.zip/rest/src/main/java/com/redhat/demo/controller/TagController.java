package com.redhat.demo.controller;

import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/")
public class TagController {
	@Autowired
	RestTemplate restTemplate;
	@Autowired
	AsnyService asnyService;

	@RequestMapping(value = "/tag", method = RequestMethod.GET)
	public String tag(@RequestHeader Map<String, String> headers) {

		return UUID.randomUUID().toString();
	}

	@RequestMapping(value = "/longtime", method = RequestMethod.GET)
	public String longtime(@RequestHeader Map<String, String> headers) throws InterruptedException {
		asnyService.callHttp("http://localhost:8080/tag");
		HttpHeaders reqheaders = new HttpHeaders();
		reqheaders.set("end-user", "vip");
		HttpEntity<String> entity = new HttpEntity<String>("parameters", reqheaders);
		try {
			ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:8081/longtime", String.class);
			System.out.println(response.getBody());
		} catch (Exception e) {
			e.printStackTrace();
		}

		return UUID.randomUUID().toString();
	}
	@RequestMapping(value = "/pingpong", method = RequestMethod.GET, params = { "count" })
	public String ping(@RequestHeader Map<String, String> headers, @RequestParam String count)
			throws InterruptedException {
		Integer c = Integer.parseInt(count);
		if (c < 10) {
			c++;
			HttpHeaders reqheaders = new HttpHeaders();
			reqheaders.set("end-user", "vip");
			HttpEntity<String> entity = new HttpEntity<String>("parameters", reqheaders);
			try {
				ResponseEntity<String> response = restTemplate
						.getForEntity("http://localhost:8081/pingpong?count=" + c.toString(), String.class);
				System.out.println(response.getBody());
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return UUID.randomUUID().toString();
	}


}

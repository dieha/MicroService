package com.redhat.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class AsnyService {

	@Autowired
	RestTemplate restTemplate;
	@Value("${rest.url}")
	String fooResourceUrl;

	@Async("asyncExecutor")
	public void callHttp() throws InterruptedException {

		HttpHeaders reqheaders = new HttpHeaders();
		reqheaders.set("end-user", "vip");
		HttpEntity<String> entity = new HttpEntity<String>("parameters", reqheaders);

		ResponseEntity<String> response = restTemplate.getForEntity(fooResourceUrl, String.class);
		System.out.println("---Asny get----" + response.getBody());
	}

	@Async("asyncExecutor")
	public void callHttp(String url) throws InterruptedException {

		HttpHeaders reqheaders = new HttpHeaders();
		reqheaders.set("end-user", "vip");
		HttpEntity<String> entity = new HttpEntity<String>("parameters", reqheaders);

		ResponseEntity<String> response = restTemplate.getForEntity(url, String.class);
		System.out.println(response.getBody());
	}

}

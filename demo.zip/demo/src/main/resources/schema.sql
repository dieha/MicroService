
CREATE TABLE  bank_code( 
	code  VARCHAR(3),
	bank_name  VARCHAR(20),
    PRIMARY KEY(code));


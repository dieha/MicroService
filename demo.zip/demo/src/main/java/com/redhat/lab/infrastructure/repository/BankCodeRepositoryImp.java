package com.redhat.lab.infrastructure.repository;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.redhat.lab.core.bankcode.entity.BankCodeVo;
import com.redhat.lab.core.bankcode.repository.BankCodeRepository;
import com.redhat.lab.infrastructure.repository.mapper.BankCodeDao;
import com.redhat.lab.infrastructure.repository.po.BankCodePo;
@Service
public class BankCodeRepositoryImp implements BankCodeRepository {

	@Resource
	BankCodeDao bankCodeDao;

	@Override
	public List<BankCodeVo> findAll() {
		List<BankCodeVo> list = new ArrayList<>();
		bankCodeDao.findAll().forEach(bankCode -> {
			list.add(new BankCodeVo(bankCode.getCode(), bankCode.getBankName()));
		});
		return list;
	}

	@Override
	public BankCodeVo save(BankCodeVo bankCodeVo) {

		BankCodePo bankCodePo = bankCodeDao.save(toPo(bankCodeVo));

		return toVo(bankCodePo);
	}

	public BankCodeVo toVo(BankCodePo bankCodePo) {
		return new BankCodeVo(bankCodePo.getCode(), bankCodePo.getBankName());
	}

	public BankCodePo toPo(BankCodeVo bankCodeVo) {
		return new BankCodePo(bankCodeVo.getCode(), bankCodeVo.getBankName());
	}

}

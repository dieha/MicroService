package com.redhat.lab.core.bankcode.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.redhat.lab.core.bankcode.entity.BankCodeVo;
import com.redhat.lab.core.bankcode.repository.BankCodeRepository;

@Service
public class BankCodeDomainService {

	@Resource
	BankCodeRepository bankCodeRepository;

	public List<BankCodeVo> queryAll() {
		List<BankCodeVo> list = bankCodeRepository.findAll();
		return list;
	}

	public BankCodeVo save() {
		// TODO Auto-generated method stub
		return null;
	}

}

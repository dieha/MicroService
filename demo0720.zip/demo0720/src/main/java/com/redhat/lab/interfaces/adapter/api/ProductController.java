package com.redhat.lab.interfaces.adapter.api;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import com.redhat.lab.interfaces.dto.ChannelProductResponse;

@RestController
public class ProductController implements ProductApi {

	
	
	@Override
	public ResponseEntity<List<ChannelProductResponse>> productProductByChannelChannelIDGet(String channelID) {
		// TODO Auto-generated method stub
		return null;
	}

}

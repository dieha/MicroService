package com.redhat.lab.core.product.entity;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProductDo {

	/**
	 * 產品 ID
	 */
	private String productId;

	/**
	 * 產品名稱
	 */
	private String productName;

	/**
	 * 產品類別
	 */
	private String productType;

	/**
	 * 通路 ID
	 */
	private String channelId;
}

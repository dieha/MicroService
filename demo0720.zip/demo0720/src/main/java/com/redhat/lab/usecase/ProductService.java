package com.redhat.lab.usecase;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.redhat.lab.core.product.service.ProductDomainService;

@Service
public class ProductService {

	@Autowired
	ProductDomainService productDomainService;

	public List<String> findPorductByChannelId(String channelId) {
		
		return null;
	}
}

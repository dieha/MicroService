package com.redhat.lab.interfaces.dto;

import java.util.Objects;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 通路商品請求內文
 */
@ApiModel(description = "通路商品請求內文")
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2022-07-19T10:43:55.467923+08:00[Asia/Taipei]")
public class ChannelProductResponse   {
  @JsonProperty("ProductId")
  private String productId;

  @JsonProperty("ProductName")
  private String productName;

  @JsonProperty("ProductType")
  private String productType;

  @JsonProperty("ChannelID")
  private String channelID;

  @JsonProperty("Amount")
  private Double amount;

  @JsonProperty("Tenor")
  private Double tenor;

  @JsonProperty("Weight")
  private Double weight;

  @JsonProperty("InterestRate")
  private Double interestRate;

  @JsonProperty("InterestFreq")
  private Integer interestFreq;

  @JsonProperty("HedgeCostRate")
  private Double hedgeCostRate;

  @JsonProperty("RateIndex")
  private String rateIndex;

  @JsonProperty("Spread")
  private Double spread;

  @JsonProperty("TaxRate")
  private Double taxRate;

  public ChannelProductResponse productId(String productId) {
    this.productId = productId;
    return this;
  }

  /**
   * 商品代號
   * @return productId
  */
  @ApiModelProperty(value = "商品代號")


  public String getProductId() {
    return productId;
  }

  public void setProductId(String productId) {
    this.productId = productId;
  }

  public ChannelProductResponse productName(String productName) {
    this.productName = productName;
    return this;
  }

  /**
   * 商品名稱
   * @return productName
  */
  @ApiModelProperty(value = "商品名稱")


  public String getProductName() {
    return productName;
  }

  public void setProductName(String productName) {
    this.productName = productName;
  }

  public ChannelProductResponse productType(String productType) {
    this.productType = productType;
    return this;
  }

  /**
   * 商品類別
   * @return productType
  */
  @ApiModelProperty(value = "商品類別")


  public String getProductType() {
    return productType;
  }

  public void setProductType(String productType) {
    this.productType = productType;
  }

  public ChannelProductResponse channelID(String channelID) {
    this.channelID = channelID;
    return this;
  }

  /**
   * 通路代號
   * @return channelID
  */
  @ApiModelProperty(required = true, value = "通路代號")
  @NotNull


  public String getChannelID() {
    return channelID;
  }

  public void setChannelID(String channelID) {
    this.channelID = channelID;
  }

  public ChannelProductResponse amount(Double amount) {
    this.amount = amount;
    return this;
  }

  /**
   * 本金
   * @return amount
  */
  @ApiModelProperty(value = "本金")


  public Double getAmount() {
    return amount;
  }

  public void setAmount(Double amount) {
    this.amount = amount;
  }

  public ChannelProductResponse tenor(Double tenor) {
    this.tenor = tenor;
    return this;
  }

  /**
   * 效期(月)
   * @return tenor
  */
  @ApiModelProperty(value = "效期(月)")


  public Double getTenor() {
    return tenor;
  }

  public void setTenor(Double tenor) {
    this.tenor = tenor;
  }

  public ChannelProductResponse weight(Double weight) {
    this.weight = weight;
    return this;
  }

  /**
   * 參與率(%)
   * @return weight
  */
  @ApiModelProperty(value = "參與率(%)")


  public Double getWeight() {
    return weight;
  }

  public void setWeight(Double weight) {
    this.weight = weight;
  }

  public ChannelProductResponse interestRate(Double interestRate) {
    this.interestRate = interestRate;
    return this;
  }

  /**
   * 配息率(%)
   * @return interestRate
  */
  @ApiModelProperty(value = "配息率(%)")


  public Double getInterestRate() {
    return interestRate;
  }

  public void setInterestRate(Double interestRate) {
    this.interestRate = interestRate;
  }

  public ChannelProductResponse interestFreq(Integer interestFreq) {
    this.interestFreq = interestFreq;
    return this;
  }

  /**
   * 配息頻率(幾個月一次)
   * @return interestFreq
  */
  @ApiModelProperty(value = "配息頻率(幾個月一次)")


  public Integer getInterestFreq() {
    return interestFreq;
  }

  public void setInterestFreq(Integer interestFreq) {
    this.interestFreq = interestFreq;
  }

  public ChannelProductResponse hedgeCostRate(Double hedgeCostRate) {
    this.hedgeCostRate = hedgeCostRate;
    return this;
  }

  /**
   * 避險資金成本(%)
   * @return hedgeCostRate
  */
  @ApiModelProperty(value = "避險資金成本(%)")


  public Double getHedgeCostRate() {
    return hedgeCostRate;
  }

  public void setHedgeCostRate(Double hedgeCostRate) {
    this.hedgeCostRate = hedgeCostRate;
  }

  public ChannelProductResponse rateIndex(String rateIndex) {
    this.rateIndex = rateIndex;
    return this;
  }

  /**
   * 避險資金成本之利率指標
   * @return rateIndex
  */
  @ApiModelProperty(value = "避險資金成本之利率指標")


  public String getRateIndex() {
    return rateIndex;
  }

  public void setRateIndex(String rateIndex) {
    this.rateIndex = rateIndex;
  }

  public ChannelProductResponse spread(Double spread) {
    this.spread = spread;
    return this;
  }

  /**
   * 利率指標加減碼(%)
   * @return spread
  */
  @ApiModelProperty(value = "利率指標加減碼(%)")


  public Double getSpread() {
    return spread;
  }

  public void setSpread(Double spread) {
    this.spread = spread;
  }

  public ChannelProductResponse taxRate(Double taxRate) {
    this.taxRate = taxRate;
    return this;
  }

  /**
   * 稅率(%)
   * @return taxRate
  */
  @ApiModelProperty(value = "稅率(%)")


  public Double getTaxRate() {
    return taxRate;
  }

  public void setTaxRate(Double taxRate) {
    this.taxRate = taxRate;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ChannelProductResponse channelProductResponse = (ChannelProductResponse) o;
    return Objects.equals(this.productId, channelProductResponse.productId) &&
        Objects.equals(this.productName, channelProductResponse.productName) &&
        Objects.equals(this.productType, channelProductResponse.productType) &&
        Objects.equals(this.channelID, channelProductResponse.channelID) &&
        Objects.equals(this.amount, channelProductResponse.amount) &&
        Objects.equals(this.tenor, channelProductResponse.tenor) &&
        Objects.equals(this.weight, channelProductResponse.weight) &&
        Objects.equals(this.interestRate, channelProductResponse.interestRate) &&
        Objects.equals(this.interestFreq, channelProductResponse.interestFreq) &&
        Objects.equals(this.hedgeCostRate, channelProductResponse.hedgeCostRate) &&
        Objects.equals(this.rateIndex, channelProductResponse.rateIndex) &&
        Objects.equals(this.spread, channelProductResponse.spread) &&
        Objects.equals(this.taxRate, channelProductResponse.taxRate);
  }

  @Override
  public int hashCode() {
    return Objects.hash(productId, productName, productType, channelID, amount, tenor, weight, interestRate, interestFreq, hedgeCostRate, rateIndex, spread, taxRate);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ChannelProductResponse {\n");
    
    sb.append("    productId: ").append(toIndentedString(productId)).append("\n");
    sb.append("    productName: ").append(toIndentedString(productName)).append("\n");
    sb.append("    productType: ").append(toIndentedString(productType)).append("\n");
    sb.append("    channelID: ").append(toIndentedString(channelID)).append("\n");
    sb.append("    amount: ").append(toIndentedString(amount)).append("\n");
    sb.append("    tenor: ").append(toIndentedString(tenor)).append("\n");
    sb.append("    weight: ").append(toIndentedString(weight)).append("\n");
    sb.append("    interestRate: ").append(toIndentedString(interestRate)).append("\n");
    sb.append("    interestFreq: ").append(toIndentedString(interestFreq)).append("\n");
    sb.append("    hedgeCostRate: ").append(toIndentedString(hedgeCostRate)).append("\n");
    sb.append("    rateIndex: ").append(toIndentedString(rateIndex)).append("\n");
    sb.append("    spread: ").append(toIndentedString(spread)).append("\n");
    sb.append("    taxRate: ").append(toIndentedString(taxRate)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}


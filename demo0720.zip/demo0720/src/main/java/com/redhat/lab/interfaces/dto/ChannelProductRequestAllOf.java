package com.redhat.lab.interfaces.dto;

import java.util.Objects;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * ChannelProductRequestAllOf
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2022-07-19T10:43:55.467923+08:00[Asia/Taipei]")
public class ChannelProductRequestAllOf   {
  @JsonProperty("ChannelID")
  private String channelID;

  public ChannelProductRequestAllOf channelID(String channelID) {
    this.channelID = channelID;
    return this;
  }

  /**
   * 通路代號
   * @return channelID
  */
  @ApiModelProperty(required = true, value = "通路代號")
  @NotNull


  public String getChannelID() {
    return channelID;
  }

  public void setChannelID(String channelID) {
    this.channelID = channelID;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ChannelProductRequestAllOf channelProductRequestAllOf = (ChannelProductRequestAllOf) o;
    return Objects.equals(this.channelID, channelProductRequestAllOf.channelID);
  }

  @Override
  public int hashCode() {
    return Objects.hash(channelID);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ChannelProductRequestAllOf {\n");
    
    sb.append("    channelID: ").append(toIndentedString(channelID)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}


package com.redhat.lab.interfaces.dto;

import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * CalculateRequestAllOf
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2022-07-19T10:43:55.467923+08:00[Asia/Taipei]")
public class CalculateRequestAllOf   {
  @JsonProperty("Amount")
  private Double amount;

  @JsonProperty("StartDate")
  private String startDate;

  @JsonProperty("EndDate")
  private String endDate;

  @JsonProperty("TaxRate")
  private Double taxRate;

  public CalculateRequestAllOf amount(Double amount) {
    this.amount = amount;
    return this;
  }

  /**
   * 本金
   * @return amount
  */
  @ApiModelProperty(value = "本金")


  public Double getAmount() {
    return amount;
  }

  public void setAmount(Double amount) {
    this.amount = amount;
  }

  public CalculateRequestAllOf startDate(String startDate) {
    this.startDate = startDate;
    return this;
  }

  /**
   * 生效日
   * @return startDate
  */
  @ApiModelProperty(value = "生效日")


  public String getStartDate() {
    return startDate;
  }

  public void setStartDate(String startDate) {
    this.startDate = startDate;
  }

  public CalculateRequestAllOf endDate(String endDate) {
    this.endDate = endDate;
    return this;
  }

  /**
   * 到期日
   * @return endDate
  */
  @ApiModelProperty(value = "到期日")


  public String getEndDate() {
    return endDate;
  }

  public void setEndDate(String endDate) {
    this.endDate = endDate;
  }

  public CalculateRequestAllOf taxRate(Double taxRate) {
    this.taxRate = taxRate;
    return this;
  }

  /**
   * 稅率(%)
   * @return taxRate
  */
  @ApiModelProperty(value = "稅率(%)")


  public Double getTaxRate() {
    return taxRate;
  }

  public void setTaxRate(Double taxRate) {
    this.taxRate = taxRate;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CalculateRequestAllOf calculateRequestAllOf = (CalculateRequestAllOf) o;
    return Objects.equals(this.amount, calculateRequestAllOf.amount) &&
        Objects.equals(this.startDate, calculateRequestAllOf.startDate) &&
        Objects.equals(this.endDate, calculateRequestAllOf.endDate) &&
        Objects.equals(this.taxRate, calculateRequestAllOf.taxRate);
  }

  @Override
  public int hashCode() {
    return Objects.hash(amount, startDate, endDate, taxRate);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CalculateRequestAllOf {\n");
    
    sb.append("    amount: ").append(toIndentedString(amount)).append("\n");
    sb.append("    startDate: ").append(toIndentedString(startDate)).append("\n");
    sb.append("    endDate: ").append(toIndentedString(endDate)).append("\n");
    sb.append("    taxRate: ").append(toIndentedString(taxRate)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}


package com.redhat.lab.interfaces.dto;

import java.util.Objects;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 基金商品建議試算請求內文
 */
@ApiModel(description = "基金商品建議試算請求內文")
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2022-07-19T10:43:55.467923+08:00[Asia/Taipei]")
public class CalculateRequest   {
  @JsonProperty("ProductId")
  private String productId;

  @JsonProperty("ProductName")
  private String productName;

  @JsonProperty("ProductType")
  private String productType;

  @JsonProperty("ChannelID")
  private String channelID;

  @JsonProperty("Amount")
  private Double amount;

  @JsonProperty("StartDate")
  private String startDate;

  @JsonProperty("EndDate")
  private String endDate;

  @JsonProperty("TaxRate")
  private Double taxRate;

  public CalculateRequest productId(String productId) {
    this.productId = productId;
    return this;
  }

  /**
   * 商品代號
   * @return productId
  */
  @ApiModelProperty(value = "商品代號")


  public String getProductId() {
    return productId;
  }

  public void setProductId(String productId) {
    this.productId = productId;
  }

  public CalculateRequest productName(String productName) {
    this.productName = productName;
    return this;
  }

  /**
   * 商品名稱
   * @return productName
  */
  @ApiModelProperty(value = "商品名稱")


  public String getProductName() {
    return productName;
  }

  public void setProductName(String productName) {
    this.productName = productName;
  }

  public CalculateRequest productType(String productType) {
    this.productType = productType;
    return this;
  }

  /**
   * 商品類別
   * @return productType
  */
  @ApiModelProperty(value = "商品類別")


  public String getProductType() {
    return productType;
  }

  public void setProductType(String productType) {
    this.productType = productType;
  }

  public CalculateRequest channelID(String channelID) {
    this.channelID = channelID;
    return this;
  }

  /**
   * 通路代號
   * @return channelID
  */
  @ApiModelProperty(required = true, value = "通路代號")
  @NotNull


  public String getChannelID() {
    return channelID;
  }

  public void setChannelID(String channelID) {
    this.channelID = channelID;
  }

  public CalculateRequest amount(Double amount) {
    this.amount = amount;
    return this;
  }

  /**
   * 本金
   * @return amount
  */
  @ApiModelProperty(value = "本金")


  public Double getAmount() {
    return amount;
  }

  public void setAmount(Double amount) {
    this.amount = amount;
  }

  public CalculateRequest startDate(String startDate) {
    this.startDate = startDate;
    return this;
  }

  /**
   * 生效日
   * @return startDate
  */
  @ApiModelProperty(value = "生效日")


  public String getStartDate() {
    return startDate;
  }

  public void setStartDate(String startDate) {
    this.startDate = startDate;
  }

  public CalculateRequest endDate(String endDate) {
    this.endDate = endDate;
    return this;
  }

  /**
   * 到期日
   * @return endDate
  */
  @ApiModelProperty(value = "到期日")


  public String getEndDate() {
    return endDate;
  }

  public void setEndDate(String endDate) {
    this.endDate = endDate;
  }

  public CalculateRequest taxRate(Double taxRate) {
    this.taxRate = taxRate;
    return this;
  }

  /**
   * 稅率(%)
   * @return taxRate
  */
  @ApiModelProperty(value = "稅率(%)")


  public Double getTaxRate() {
    return taxRate;
  }

  public void setTaxRate(Double taxRate) {
    this.taxRate = taxRate;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CalculateRequest calculateRequest = (CalculateRequest) o;
    return Objects.equals(this.productId, calculateRequest.productId) &&
        Objects.equals(this.productName, calculateRequest.productName) &&
        Objects.equals(this.productType, calculateRequest.productType) &&
        Objects.equals(this.channelID, calculateRequest.channelID) &&
        Objects.equals(this.amount, calculateRequest.amount) &&
        Objects.equals(this.startDate, calculateRequest.startDate) &&
        Objects.equals(this.endDate, calculateRequest.endDate) &&
        Objects.equals(this.taxRate, calculateRequest.taxRate);
  }

  @Override
  public int hashCode() {
    return Objects.hash(productId, productName, productType, channelID, amount, startDate, endDate, taxRate);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CalculateRequest {\n");
    
    sb.append("    productId: ").append(toIndentedString(productId)).append("\n");
    sb.append("    productName: ").append(toIndentedString(productName)).append("\n");
    sb.append("    productType: ").append(toIndentedString(productType)).append("\n");
    sb.append("    channelID: ").append(toIndentedString(channelID)).append("\n");
    sb.append("    amount: ").append(toIndentedString(amount)).append("\n");
    sb.append("    startDate: ").append(toIndentedString(startDate)).append("\n");
    sb.append("    endDate: ").append(toIndentedString(endDate)).append("\n");
    sb.append("    taxRate: ").append(toIndentedString(taxRate)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}


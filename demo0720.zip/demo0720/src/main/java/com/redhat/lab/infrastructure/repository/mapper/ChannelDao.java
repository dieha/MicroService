package com.redhat.lab.infrastructure.repository.mapper;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.redhat.lab.infrastructure.repository.po.ChannelPo;

@Repository
public interface ChannelDao extends JpaRepository<ChannelPo, String> {

}

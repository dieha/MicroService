package com.redhat.lab.interfaces.dto;

import java.util.Objects;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * CalculateResponse
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2022-07-19T10:43:55.467923+08:00[Asia/Taipei]")
public class CalculateResponse   {
  @JsonProperty("ChannelID")
  private String channelID;

  @JsonProperty("ProductId")
  private String productId;

  @JsonProperty("ProductName")
  private String productName;

  @JsonProperty("ProductType")
  private String productType;

  @JsonProperty("Detail")
  private CalculateDetail detail;

  public CalculateResponse channelID(String channelID) {
    this.channelID = channelID;
    return this;
  }

  /**
   * 通路代號
   * @return channelID
  */
  @ApiModelProperty(value = "通路代號")


  public String getChannelID() {
    return channelID;
  }

  public void setChannelID(String channelID) {
    this.channelID = channelID;
  }

  public CalculateResponse productId(String productId) {
    this.productId = productId;
    return this;
  }

  /**
   * 商品代號
   * @return productId
  */
  @ApiModelProperty(value = "商品代號")


  public String getProductId() {
    return productId;
  }

  public void setProductId(String productId) {
    this.productId = productId;
  }

  public CalculateResponse productName(String productName) {
    this.productName = productName;
    return this;
  }

  /**
   * 商品名稱
   * @return productName
  */
  @ApiModelProperty(value = "商品名稱")


  public String getProductName() {
    return productName;
  }

  public void setProductName(String productName) {
    this.productName = productName;
  }

  public CalculateResponse productType(String productType) {
    this.productType = productType;
    return this;
  }

  /**
   * 商品類別
   * @return productType
  */
  @ApiModelProperty(value = "商品類別")


  public String getProductType() {
    return productType;
  }

  public void setProductType(String productType) {
    this.productType = productType;
  }

  public CalculateResponse detail(CalculateDetail detail) {
    this.detail = detail;
    return this;
  }

  /**
   * Get detail
   * @return detail
  */
  @ApiModelProperty(value = "")

  @Valid

  public CalculateDetail getDetail() {
    return detail;
  }

  public void setDetail(CalculateDetail detail) {
    this.detail = detail;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CalculateResponse calculateResponse = (CalculateResponse) o;
    return Objects.equals(this.channelID, calculateResponse.channelID) &&
        Objects.equals(this.productId, calculateResponse.productId) &&
        Objects.equals(this.productName, calculateResponse.productName) &&
        Objects.equals(this.productType, calculateResponse.productType) &&
        Objects.equals(this.detail, calculateResponse.detail);
  }

  @Override
  public int hashCode() {
    return Objects.hash(channelID, productId, productName, productType, detail);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CalculateResponse {\n");
    
    sb.append("    channelID: ").append(toIndentedString(channelID)).append("\n");
    sb.append("    productId: ").append(toIndentedString(productId)).append("\n");
    sb.append("    productName: ").append(toIndentedString(productName)).append("\n");
    sb.append("    productType: ").append(toIndentedString(productType)).append("\n");
    sb.append("    detail: ").append(toIndentedString(detail)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}


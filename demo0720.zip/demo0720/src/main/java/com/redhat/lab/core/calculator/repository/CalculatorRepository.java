package com.redhat.lab.core.calculator.repository;

public interface CalculatorRepository {

}

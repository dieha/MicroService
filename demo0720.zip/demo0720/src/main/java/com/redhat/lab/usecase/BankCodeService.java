package com.redhat.lab.usecase;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.redhat.lab.core.bankcode.entity.BankCodeVo;
import com.redhat.lab.core.bankcode.service.BankCodeDomainService;

@Service
public class BankCodeService {

	@Resource
	BankCodeDomainService bankCodeDomainService;

	public List<BankCodeVo> all() {
		List<BankCodeVo> list = bankCodeDomainService.queryAll();
		return list;
	}

}

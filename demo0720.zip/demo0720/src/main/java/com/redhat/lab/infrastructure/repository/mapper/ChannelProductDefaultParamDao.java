package com.redhat.lab.infrastructure.repository.mapper;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.redhat.lab.infrastructure.repository.po.ChannelPo;
import com.redhat.lab.infrastructure.repository.po.ChannelProductDefaultParamPo;
import com.redhat.lab.infrastructure.repository.po.ProductPo;

@Repository
public interface ChannelProductDefaultParamDao extends JpaRepository<ChannelProductDefaultParamPo, Integer> {

	/**
	 * findByChannelPo
	 * @param channelId
	 * @return
	 */
	List<ChannelProductDefaultParamPo> findByChannelPo(ChannelPo channelPo);
	
	/**
	 * findByProductPo
	 * @param productId
	 * @return
	 */
	List<ChannelProductDefaultParamPo> findByProductPo(ProductPo productPo);
}

package com.redhat.lab.infrastructure.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.redhat.lab.core.product.entity.ProductDo;
import com.redhat.lab.core.product.repository.ProductRepository;
import com.redhat.lab.infrastructure.common.api.MockServiceAapter;
import com.redhat.lab.infrastructure.repository.mapper.ChannelProductDao;
import com.redhat.lab.infrastructure.repository.mapper.ChannelProductDefaultParamDao;
import com.redhat.lab.infrastructure.repository.mapper.ProductDao;
import com.redhat.lab.infrastructure.repository.po.ChannelPo;

@Service
public class ProductRepositoryImpl implements ProductRepository {

	@Autowired
	ProductDao productDao;

	@Autowired
	ChannelProductDao channelProductDao;
	
	@Autowired
	ChannelProductDefaultParamDao channelProductDefaultParamDao;
	
	@Autowired
	MockServiceAapter mockServiceAapter;

	@Override
	public List<ProductDo> findByChannelId(String channelId) {
		ChannelPo cPo=ChannelPo.builder().channelId(channelId).build();
		String a =channelProductDao.findByChannelPo(cPo).get(0).getProductPo().getProductName();
		String b =channelProductDao.findByChannelPo(cPo).get(1).getProductPo().getProductName();
		System.out.println(a);
		System.out.println(b);

		//productDao.findById(channelId);
//		ChannelPo cPo=ChannelPo.builder().channelId(channelId).build();
//		String a =channelProductDao.findByChannelPo(cPo).get(0).getProductPo().getProductName();
//		String b =channelProductDao.findByChannelPo(cPo).get(1).getProductPo().getProductName();
//		String c =channelProductDefaultParamDao.findByChannelPo(cPo).get(0).getRateIndex();
//		String d =channelProductDefaultParamDao.findByChannelPo(cPo).get(1).getRateIndex();
//		System.out.println(a);
//		System.out.println(b);
//		System.out.println(c);
//		System.out.println(d);
		
		return null;
	}

}

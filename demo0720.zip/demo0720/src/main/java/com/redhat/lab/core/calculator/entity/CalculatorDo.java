package com.redhat.lab.core.calculator.entity;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CalculatorDo {

	/**
	 * 本金
	 */
	private BigDecimal amount;

	/**
	 * 生效日
	 */
	private String startDate;

	/**
	 * 到期日
	 */
	private String endDate;

	/**
	 * 參與率(%)
	 */
	private BigDecimal weight;

	/**
	 * 配息率(%)
	 */
	private BigDecimal interestRate;

	/**
	 * 配息頻率(幾個月一次)
	 */
	private int interestFreq;

	/**
	 * 避險資金成本(%)
	 */
	private BigDecimal hedgeCostRate;

	/**
	 * 避險資金成本之利率指標
	 */
	private String rateIndex;

	/**
	 * 避利率指標加減碼(%)
	 */
	private String spread;

	/**
	 * 稅率
	 */
	private BigDecimal taxRate;
	
	/**
	 * 報酬率(%)
	 */
	private BigDecimal returnRate;

	/**
	 * 累積配息金額
	 */
	private BigDecimal accumulatedInterestAmount;
	
	/**
	 * 契約價格(%)
	 */
	private BigDecimal contractPrice;
	
	/**
	 * 現值
	 */
	private BigDecimal presentAmount;
	
}

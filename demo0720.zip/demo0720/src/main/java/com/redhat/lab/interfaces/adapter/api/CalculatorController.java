package com.redhat.lab.interfaces.adapter.api;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import com.redhat.lab.interfaces.dto.CalculateRequest;
import com.redhat.lab.interfaces.dto.CalculateResponse;
import com.redhat.lab.usecase.CalculatorService;


@RestController
public class CalculatorController implements CalculatorApi {

	@Autowired
	CalculatorService calculatorService;
	
	@Override
	public ResponseEntity<CalculateResponse> calculatorCalculatePost(@Valid CalculateRequest calculateRequest) {
		// TODO Auto-generated method stub
		return null;
	}

}

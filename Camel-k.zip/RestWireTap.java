// camel-k: profile=openshift
// camel-k: trait=logging.json=true

import org.apache.camel.Exchange;
import org.apache.camel.builder.RouteBuilder;

public class RestWireTap extends RouteBuilder {
    @Override
    public void configure() throws Exception {
       
        rest()
            .post("/camel")
                .to("direct:camel");

        from("direct:camel")
            .to("direct:log")
            .wireTap("direct:tap")
            .to("direct:hello");
            
        from("direct:hello")
            .setHeader(Exchange.CONTENT_TYPE, constant("text/plain"))
            .transform().simple( "hello")
            .log("${body}");
        
        from("direct:log")
            .log(" api : ${body} ");

        from("direct:tap")
            .log(" tap : ${body}");
        
    }


}



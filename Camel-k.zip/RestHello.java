// camel-k: profile=openshift

import org.apache.camel.Exchange;
import org.apache.camel.builder.RouteBuilder;

public class RestHello extends RouteBuilder {
    @Override
    public void configure() throws Exception {
        rest()
            .get("/hello")
            .to("direct:hello")
            .post("/hello")
            .to("direct:hello");

        from("direct:hello")
        .log("${body}")
            .setHeader(Exchange.CONTENT_TYPE, constant("text/plain"))
            .transform().simple( "hello");

    }


}



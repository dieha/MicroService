// camel-k: language=java property=file:application.properties

import org.apache.camel.Exchange;
import org.apache.camel.builder.RouteBuilder;
import java.util.Map;

public class KafkaConsumer extends RouteBuilder {
    @Override
    public void configure() throws Exception {
       

        from("kafka:{{consumer.topic}}?brokers={{kafka.host}}:{{kafka.port}}"
        + "&maxPollRecords={{consumer.maxPollRecords}}"
        + "&consumersCount={{consumer.consumersCount}}"
        + "&seekTo={{consumer.seekTo}}"
        + "&groupId={{consumer.group}}")
            .routeId("CamelKafka")
            .log("Kafka:${body}");
        
    }
}
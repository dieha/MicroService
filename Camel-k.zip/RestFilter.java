// camel-k: profile=openshift
// camel-k: trait=logging.json=true

import org.apache.camel.Exchange;
import org.apache.camel.builder.RouteBuilder;

public class RestFilter extends RouteBuilder {
    @Override
    public void configure() throws Exception {
       
        rest()
            .post("/camel")
                .to("direct:camel");

        from("direct:camel")
            .filter(simple("${header.foo} == 'bar'"))
                .log("filter:${header.foo}")
            .end()
            .log("api:${body}");
        
    }


}



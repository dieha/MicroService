// camel-k: profile=openshift

import org.apache.camel.Exchange;
import org.apache.camel.builder.RouteBuilder;

public class RestToKafka extends RouteBuilder {
    @Override
    public void configure() throws Exception {
       
        rest()
            .post("/camel")
                .to("direct:camel");

        from("direct:camel")
            .log("api:${body}")
            .to("kafka:my-topic?brokers={{kafka.host}}:{{kafka.port}}");
        
    }


}



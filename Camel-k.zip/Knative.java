
import org.apache.camel.Exchange;
import org.apache.camel.builder.RouteBuilder;
import java.util.Map;


public class Knative extends RouteBuilder {
    @Override
    public void configure() throws Exception {
       
        from("knative:channel/camel")
            .routeId("Knative")
            .log("Knative")
            .to("direct:camel");

        from("direct:camel")
            .log("api:${body}")
            .to("kafka:my-topic?brokers={{kafka.host}}:{{kafka.port}}");
    
            
        
    }


}



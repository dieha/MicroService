from kraken.plugins import PLUGINS

if __name__ == "__main__":
    print(PLUGINS.json_schema())
package com.redhat.lab.infrastructure.common.dto;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MockApiRequest {

	/**
	 * 
	 */
	private String ChannelID;
	
	/**
	 * 
	 */
	private String ProductId;
	
	/**
	 * 
	 */
	private String ProductName;
	
	/**
	 * 
	 */
	private String ProductType;
	
	/**
	 * 
	 */
	private BigDecimal Amount;
	
	/**
	 * 
	 */
	private String StartDate;
	
	/**
	 * 
	 */
	private String EndDate;
	
	/**
	 * 
	 */
	private BigDecimal Weight;
	
	/**
	 * 
	 */
	private BigDecimal InterestRate;
	
	/**
	 * 
	 */
	private int InterestFreq;
	
	/**
	 * 
	 */
	private BigDecimal HedgeCostRate;
	
	/**
	 * 
	 */
	private String RateIndex;
	
	/**
	 * 
	 */
	private BigDecimal Spread;
	
	/**
	 * 
	 */
	private BigDecimal TaxRate;
	
	/**
	 * 
	 */
	private String UnderlyingId;

}

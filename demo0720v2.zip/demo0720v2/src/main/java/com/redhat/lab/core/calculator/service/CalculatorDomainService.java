package com.redhat.lab.core.calculator.service;

import org.springframework.stereotype.Service;

@Service
public class CalculatorDomainService {

}

package com.redhat.lab.infrastructure.common.api;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.redhat.lab.infrastructure.util.RestClientUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class MockServiceAapter {

	@Autowired
	RestClientUtil restClient;

	@Value("${mock.apiUrl}")
	String mockApiUrl;

	public void callMock() {
		String response = restClient.get(mockApiUrl, String.class, new HashMap<>());
		log.info("Mock API Output : {}", response);
	}
}

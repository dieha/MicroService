package com.redhat.lab.usecase;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.redhat.lab.core.product.service.ProductDomainService;

@Service
public class ProductService {

	@Autowired
	ProductDomainService productDomainService;

	public void execute() {
		// 1. 依照通路查出有哪些產品以及預設參數 ChannelProductDefaultParamDao
		// 2. 提供 Calculator 試算的預設參數
		
	}
	
}

package com.redhat.lab.infrastructure.repository.po;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "CHANNEL")
public class ChannelPo {

	@Id
	@Column(name = "CHANNEL_ID", length = 20)
	private String channelId;

	@Column(name = "CHANNEL_NAME", length = 20)
	private String channelName;
	
	@OneToMany(mappedBy = "channelPo")
	private Set<ChannelProductPo> channelProduct;
	
	@OneToMany(mappedBy = "channelPo")
	private Set<ChannelProductDefaultParamPo> channelProductDefaultParamPo;
	
}

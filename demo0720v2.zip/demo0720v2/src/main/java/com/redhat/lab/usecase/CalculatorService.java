package com.redhat.lab.usecase;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.redhat.lab.core.calculator.service.CalculatorDomainService;
import com.redhat.lab.core.product.service.ProductDomainService;
import com.redhat.lab.infrastructure.common.api.MockServiceAapter;

@Service
public class CalculatorService {

	@Autowired
	CalculatorDomainService calculatorDomainService;
	
	@Autowired
	ProductDomainService productDomainService;

	@Autowired
	MockServiceAapter mockServiceAapter;
	
	public void execute() {
		// 1. 查詢預設參數
		
		// 2. Call 試算 Mock Service (Infra > common > MockServiceAapter)
		
		// 3. 回應
	}
}

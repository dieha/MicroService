package com.redhat.lab.infrastructure.repository.mapper;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.redhat.lab.infrastructure.repository.po.ProductPo;

@Repository
public interface ProductDao extends JpaRepository<ProductPo, String> {

}

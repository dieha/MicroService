package com.redhat.lab.core.product.repository;

import java.util.List;

import com.redhat.lab.core.product.entity.ProductDo;

public interface ProductRepository {

	List<ProductDo> findByChannelId(String channelId);
}

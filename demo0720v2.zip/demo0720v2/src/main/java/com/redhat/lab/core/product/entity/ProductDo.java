package com.redhat.lab.core.product.entity;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.redhat.lab.core.product.entity.vo.DefaultValueVo;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProductDo {

	/**
	 * 產品 ID
	 */
	private String productId;
	
	/**
	 * 通路 ID
	 */
	private String channelId;

	/**
	 * 產品名稱
	 */
	private String productName;

	/**
	 * 產品類別
	 */
	private String productType;

	/**
	 * 連結標的代碼
	 */
	private String underlyingId;
	
	/**
	 * 產品預設參數值
	 */
	private DefaultValueVo defaultValueVo;
	
}

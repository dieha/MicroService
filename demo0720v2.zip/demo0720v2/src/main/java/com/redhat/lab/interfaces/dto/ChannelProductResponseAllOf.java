package com.redhat.lab.interfaces.dto;

import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * ChannelProductResponseAllOf
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2022-07-19T10:43:55.467923+08:00[Asia/Taipei]")
public class ChannelProductResponseAllOf   {
  @JsonProperty("Amount")
  private Double amount;

  @JsonProperty("Tenor")
  private Double tenor;

  @JsonProperty("Weight")
  private Double weight;

  @JsonProperty("InterestRate")
  private Double interestRate;

  @JsonProperty("InterestFreq")
  private Integer interestFreq;

  @JsonProperty("HedgeCostRate")
  private Double hedgeCostRate;

  @JsonProperty("RateIndex")
  private String rateIndex;

  @JsonProperty("Spread")
  private Double spread;

  @JsonProperty("TaxRate")
  private Double taxRate;

  public ChannelProductResponseAllOf amount(Double amount) {
    this.amount = amount;
    return this;
  }

  /**
   * 本金
   * @return amount
  */
  @ApiModelProperty(value = "本金")


  public Double getAmount() {
    return amount;
  }

  public void setAmount(Double amount) {
    this.amount = amount;
  }

  public ChannelProductResponseAllOf tenor(Double tenor) {
    this.tenor = tenor;
    return this;
  }

  /**
   * 效期(月)
   * @return tenor
  */
  @ApiModelProperty(value = "效期(月)")


  public Double getTenor() {
    return tenor;
  }

  public void setTenor(Double tenor) {
    this.tenor = tenor;
  }

  public ChannelProductResponseAllOf weight(Double weight) {
    this.weight = weight;
    return this;
  }

  /**
   * 參與率(%)
   * @return weight
  */
  @ApiModelProperty(value = "參與率(%)")


  public Double getWeight() {
    return weight;
  }

  public void setWeight(Double weight) {
    this.weight = weight;
  }

  public ChannelProductResponseAllOf interestRate(Double interestRate) {
    this.interestRate = interestRate;
    return this;
  }

  /**
   * 配息率(%)
   * @return interestRate
  */
  @ApiModelProperty(value = "配息率(%)")


  public Double getInterestRate() {
    return interestRate;
  }

  public void setInterestRate(Double interestRate) {
    this.interestRate = interestRate;
  }

  public ChannelProductResponseAllOf interestFreq(Integer interestFreq) {
    this.interestFreq = interestFreq;
    return this;
  }

  /**
   * 配息頻率(幾個月一次)
   * @return interestFreq
  */
  @ApiModelProperty(value = "配息頻率(幾個月一次)")


  public Integer getInterestFreq() {
    return interestFreq;
  }

  public void setInterestFreq(Integer interestFreq) {
    this.interestFreq = interestFreq;
  }

  public ChannelProductResponseAllOf hedgeCostRate(Double hedgeCostRate) {
    this.hedgeCostRate = hedgeCostRate;
    return this;
  }

  /**
   * 避險資金成本(%)
   * @return hedgeCostRate
  */
  @ApiModelProperty(value = "避險資金成本(%)")


  public Double getHedgeCostRate() {
    return hedgeCostRate;
  }

  public void setHedgeCostRate(Double hedgeCostRate) {
    this.hedgeCostRate = hedgeCostRate;
  }

  public ChannelProductResponseAllOf rateIndex(String rateIndex) {
    this.rateIndex = rateIndex;
    return this;
  }

  /**
   * 避險資金成本之利率指標
   * @return rateIndex
  */
  @ApiModelProperty(value = "避險資金成本之利率指標")


  public String getRateIndex() {
    return rateIndex;
  }

  public void setRateIndex(String rateIndex) {
    this.rateIndex = rateIndex;
  }

  public ChannelProductResponseAllOf spread(Double spread) {
    this.spread = spread;
    return this;
  }

  /**
   * 利率指標加減碼(%)
   * @return spread
  */
  @ApiModelProperty(value = "利率指標加減碼(%)")


  public Double getSpread() {
    return spread;
  }

  public void setSpread(Double spread) {
    this.spread = spread;
  }

  public ChannelProductResponseAllOf taxRate(Double taxRate) {
    this.taxRate = taxRate;
    return this;
  }

  /**
   * 稅率(%)
   * @return taxRate
  */
  @ApiModelProperty(value = "稅率(%)")


  public Double getTaxRate() {
    return taxRate;
  }

  public void setTaxRate(Double taxRate) {
    this.taxRate = taxRate;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ChannelProductResponseAllOf channelProductResponseAllOf = (ChannelProductResponseAllOf) o;
    return Objects.equals(this.amount, channelProductResponseAllOf.amount) &&
        Objects.equals(this.tenor, channelProductResponseAllOf.tenor) &&
        Objects.equals(this.weight, channelProductResponseAllOf.weight) &&
        Objects.equals(this.interestRate, channelProductResponseAllOf.interestRate) &&
        Objects.equals(this.interestFreq, channelProductResponseAllOf.interestFreq) &&
        Objects.equals(this.hedgeCostRate, channelProductResponseAllOf.hedgeCostRate) &&
        Objects.equals(this.rateIndex, channelProductResponseAllOf.rateIndex) &&
        Objects.equals(this.spread, channelProductResponseAllOf.spread) &&
        Objects.equals(this.taxRate, channelProductResponseAllOf.taxRate);
  }

  @Override
  public int hashCode() {
    return Objects.hash(amount, tenor, weight, interestRate, interestFreq, hedgeCostRate, rateIndex, spread, taxRate);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ChannelProductResponseAllOf {\n");
    
    sb.append("    amount: ").append(toIndentedString(amount)).append("\n");
    sb.append("    tenor: ").append(toIndentedString(tenor)).append("\n");
    sb.append("    weight: ").append(toIndentedString(weight)).append("\n");
    sb.append("    interestRate: ").append(toIndentedString(interestRate)).append("\n");
    sb.append("    interestFreq: ").append(toIndentedString(interestFreq)).append("\n");
    sb.append("    hedgeCostRate: ").append(toIndentedString(hedgeCostRate)).append("\n");
    sb.append("    rateIndex: ").append(toIndentedString(rateIndex)).append("\n");
    sb.append("    spread: ").append(toIndentedString(spread)).append("\n");
    sb.append("    taxRate: ").append(toIndentedString(taxRate)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}


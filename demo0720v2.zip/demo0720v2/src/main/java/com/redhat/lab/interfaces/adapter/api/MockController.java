package com.redhat.lab.interfaces.adapter.api;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MockController {

	@GetMapping(value="/mock",produces ="application/json")
	public ResponseEntity<String> mock(HttpServletRequest request) {
		String body="{\n"
				+ "  \"ChannelID\": \"String\",\n"
				+ "  \"ProductId\": \"String\",\n"
				+ "  \"ProductName\": \"String\",\n"
				+ "  \"ProductType\": \"String\",\n"
				+ "  \"Amount\": 0,\n"
				+ "  \"StartDate\": \"String\",\n"
				+ "  \"EndDate\": \"String\",\n"
				+ "  \"Weight\": 0,\n"
				+ "  \"InterestRate\": 0,\n"
				+ "  \"InterestFreq\": \"String\",\n"
				+ "  \"HedgeCostRate\": 0.0,\n"
				+ "  \"RateIndex\": \"String\",\n"
				+ "  \"Spread\": 0,\n"
				+ "  \"TaxRate\": 0,\n"
				+ "  \"ReturnRate\": 0,\n"
				+ "  \"AccumulatedInterestAmount\": 0,\n"
				+ "  \"ContractPrice\": 0,\n"
				+ "  \"PresentAmount\": 0\n"
				+ "}";
		return new ResponseEntity<>(body, HttpStatus.OK);
	}
}

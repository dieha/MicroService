package com.redhat.lab.infrastructure.repository.po;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "CHANNEL_PRODUCT_DEFAULT_PARAM")
public class ChannelProductDefaultParamPo implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "ID")
	private int id;
	
	@ManyToOne
	@JoinColumn(name = "CHANNEL_ID")
	private ChannelPo channelPo;

	@ManyToOne
	@JoinColumn(name = "PRODUCT_ID")
	private ProductPo productPo;

	@Column(name = "AMOUNT")
	private BigDecimal amount;

	@Column(name = "TENOR")
	private int tenor;

	@Column(name = "WEIGHT")
	private BigDecimal weight;

	@Column(name = "INTEREST_RATE")
	private BigDecimal interestRate;

	@Column(name = "INTEREST_FREQ")
	private int interestFreq;

	@Column(name = "HEDGE_COST_RATE")
	private BigDecimal hedgeCodeRate;

	@Column(name = "RATE_INDEX")
	private String rateIndex;

	@Column(name = "SPREAD")
	private BigDecimal spread;

	@Column(name = "TAX_RATE")
	private BigDecimal taxRate;

}

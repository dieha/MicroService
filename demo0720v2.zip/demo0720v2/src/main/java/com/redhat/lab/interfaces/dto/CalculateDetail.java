package com.redhat.lab.interfaces.dto;

import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 試算明細
 */
@ApiModel(description = "試算明細")
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2022-07-19T10:43:55.467923+08:00[Asia/Taipei]")
public class CalculateDetail   {
  @JsonProperty("Amount")
  private Double amount;

  @JsonProperty("StartDate")
  private String startDate;

  @JsonProperty("EndDate")
  private String endDate;

  @JsonProperty("Weight")
  private Double weight;

  @JsonProperty("InterestRate")
  private Double interestRate;

  @JsonProperty("InterestFreq")
  private Integer interestFreq;

  @JsonProperty("HedgeCostRate")
  private Double hedgeCostRate;

  @JsonProperty("RateIndex")
  private String rateIndex;

  @JsonProperty("Spread")
  private Double spread;

  @JsonProperty("TaxRate")
  private Double taxRate;

  @JsonProperty("ReturnRate")
  private Double returnRate;

  @JsonProperty("AccumulatedInterestAmount")
  private Double accumulatedInterestAmount;

  @JsonProperty("ContractPrice")
  private Double contractPrice;

  @JsonProperty("PresentAmount")
  private Double presentAmount;

  public CalculateDetail amount(Double amount) {
    this.amount = amount;
    return this;
  }

  /**
   * 本金
   * @return amount
  */
  @ApiModelProperty(value = "本金")


  public Double getAmount() {
    return amount;
  }

  public void setAmount(Double amount) {
    this.amount = amount;
  }

  public CalculateDetail startDate(String startDate) {
    this.startDate = startDate;
    return this;
  }

  /**
   * 生效日
   * @return startDate
  */
  @ApiModelProperty(value = "生效日")


  public String getStartDate() {
    return startDate;
  }

  public void setStartDate(String startDate) {
    this.startDate = startDate;
  }

  public CalculateDetail endDate(String endDate) {
    this.endDate = endDate;
    return this;
  }

  /**
   * 到期日
   * @return endDate
  */
  @ApiModelProperty(value = "到期日")


  public String getEndDate() {
    return endDate;
  }

  public void setEndDate(String endDate) {
    this.endDate = endDate;
  }

  public CalculateDetail weight(Double weight) {
    this.weight = weight;
    return this;
  }

  /**
   * 參與率(%)
   * @return weight
  */
  @ApiModelProperty(value = "參與率(%)")


  public Double getWeight() {
    return weight;
  }

  public void setWeight(Double weight) {
    this.weight = weight;
  }

  public CalculateDetail interestRate(Double interestRate) {
    this.interestRate = interestRate;
    return this;
  }

  /**
   * 配息率(%)
   * @return interestRate
  */
  @ApiModelProperty(value = "配息率(%)")


  public Double getInterestRate() {
    return interestRate;
  }

  public void setInterestRate(Double interestRate) {
    this.interestRate = interestRate;
  }

  public CalculateDetail interestFreq(Integer interestFreq) {
    this.interestFreq = interestFreq;
    return this;
  }

  /**
   * 配息頻率(幾個月一次)
   * @return interestFreq
  */
  @ApiModelProperty(value = "配息頻率(幾個月一次)")


  public Integer getInterestFreq() {
    return interestFreq;
  }

  public void setInterestFreq(Integer interestFreq) {
    this.interestFreq = interestFreq;
  }

  public CalculateDetail hedgeCostRate(Double hedgeCostRate) {
    this.hedgeCostRate = hedgeCostRate;
    return this;
  }

  /**
   * 避險資金成本(%)
   * @return hedgeCostRate
  */
  @ApiModelProperty(value = "避險資金成本(%)")


  public Double getHedgeCostRate() {
    return hedgeCostRate;
  }

  public void setHedgeCostRate(Double hedgeCostRate) {
    this.hedgeCostRate = hedgeCostRate;
  }

  public CalculateDetail rateIndex(String rateIndex) {
    this.rateIndex = rateIndex;
    return this;
  }

  /**
   * 避險資金成本之利率指標
   * @return rateIndex
  */
  @ApiModelProperty(value = "避險資金成本之利率指標")


  public String getRateIndex() {
    return rateIndex;
  }

  public void setRateIndex(String rateIndex) {
    this.rateIndex = rateIndex;
  }

  public CalculateDetail spread(Double spread) {
    this.spread = spread;
    return this;
  }

  /**
   * 利率指標加減碼(%)
   * @return spread
  */
  @ApiModelProperty(value = "利率指標加減碼(%)")


  public Double getSpread() {
    return spread;
  }

  public void setSpread(Double spread) {
    this.spread = spread;
  }

  public CalculateDetail taxRate(Double taxRate) {
    this.taxRate = taxRate;
    return this;
  }

  /**
   * 稅率(%)
   * @return taxRate
  */
  @ApiModelProperty(value = "稅率(%)")


  public Double getTaxRate() {
    return taxRate;
  }

  public void setTaxRate(Double taxRate) {
    this.taxRate = taxRate;
  }

  public CalculateDetail returnRate(Double returnRate) {
    this.returnRate = returnRate;
    return this;
  }

  /**
   * 報酬率(%)
   * @return returnRate
  */
  @ApiModelProperty(value = "報酬率(%)")


  public Double getReturnRate() {
    return returnRate;
  }

  public void setReturnRate(Double returnRate) {
    this.returnRate = returnRate;
  }

  public CalculateDetail accumulatedInterestAmount(Double accumulatedInterestAmount) {
    this.accumulatedInterestAmount = accumulatedInterestAmount;
    return this;
  }

  /**
   * 累積配息金額
   * @return accumulatedInterestAmount
  */
  @ApiModelProperty(value = "累積配息金額")


  public Double getAccumulatedInterestAmount() {
    return accumulatedInterestAmount;
  }

  public void setAccumulatedInterestAmount(Double accumulatedInterestAmount) {
    this.accumulatedInterestAmount = accumulatedInterestAmount;
  }

  public CalculateDetail contractPrice(Double contractPrice) {
    this.contractPrice = contractPrice;
    return this;
  }

  /**
   * 契約價格(%)
   * @return contractPrice
  */
  @ApiModelProperty(value = "契約價格(%)")


  public Double getContractPrice() {
    return contractPrice;
  }

  public void setContractPrice(Double contractPrice) {
    this.contractPrice = contractPrice;
  }

  public CalculateDetail presentAmount(Double presentAmount) {
    this.presentAmount = presentAmount;
    return this;
  }

  /**
   * 現值
   * @return presentAmount
  */
  @ApiModelProperty(value = "現值")


  public Double getPresentAmount() {
    return presentAmount;
  }

  public void setPresentAmount(Double presentAmount) {
    this.presentAmount = presentAmount;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CalculateDetail calculateDetail = (CalculateDetail) o;
    return Objects.equals(this.amount, calculateDetail.amount) &&
        Objects.equals(this.startDate, calculateDetail.startDate) &&
        Objects.equals(this.endDate, calculateDetail.endDate) &&
        Objects.equals(this.weight, calculateDetail.weight) &&
        Objects.equals(this.interestRate, calculateDetail.interestRate) &&
        Objects.equals(this.interestFreq, calculateDetail.interestFreq) &&
        Objects.equals(this.hedgeCostRate, calculateDetail.hedgeCostRate) &&
        Objects.equals(this.rateIndex, calculateDetail.rateIndex) &&
        Objects.equals(this.spread, calculateDetail.spread) &&
        Objects.equals(this.taxRate, calculateDetail.taxRate) &&
        Objects.equals(this.returnRate, calculateDetail.returnRate) &&
        Objects.equals(this.accumulatedInterestAmount, calculateDetail.accumulatedInterestAmount) &&
        Objects.equals(this.contractPrice, calculateDetail.contractPrice) &&
        Objects.equals(this.presentAmount, calculateDetail.presentAmount);
  }

  @Override
  public int hashCode() {
    return Objects.hash(amount, startDate, endDate, weight, interestRate, interestFreq, hedgeCostRate, rateIndex, spread, taxRate, returnRate, accumulatedInterestAmount, contractPrice, presentAmount);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CalculateDetail {\n");
    
    sb.append("    amount: ").append(toIndentedString(amount)).append("\n");
    sb.append("    startDate: ").append(toIndentedString(startDate)).append("\n");
    sb.append("    endDate: ").append(toIndentedString(endDate)).append("\n");
    sb.append("    weight: ").append(toIndentedString(weight)).append("\n");
    sb.append("    interestRate: ").append(toIndentedString(interestRate)).append("\n");
    sb.append("    interestFreq: ").append(toIndentedString(interestFreq)).append("\n");
    sb.append("    hedgeCostRate: ").append(toIndentedString(hedgeCostRate)).append("\n");
    sb.append("    rateIndex: ").append(toIndentedString(rateIndex)).append("\n");
    sb.append("    spread: ").append(toIndentedString(spread)).append("\n");
    sb.append("    taxRate: ").append(toIndentedString(taxRate)).append("\n");
    sb.append("    returnRate: ").append(toIndentedString(returnRate)).append("\n");
    sb.append("    accumulatedInterestAmount: ").append(toIndentedString(accumulatedInterestAmount)).append("\n");
    sb.append("    contractPrice: ").append(toIndentedString(contractPrice)).append("\n");
    sb.append("    presentAmount: ").append(toIndentedString(presentAmount)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}


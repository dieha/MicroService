package com.redhat.lab.core.product.entity.vo;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DefaultValueVo {

	/**
	 * 本金
	 */
	private BigDecimal amount;

	/**
	 * 效期
	 */
	private int tenor;

	/**
	 * 參與率(%)
	 */
	private BigDecimal weight;

	/**
	 * 配息率(%)
	 */
	private BigDecimal interestRate;

	/**
	 * 配息頻率(幾個月一次)
	 */
	private int interestFreq;

	/**
	 * 避險資金成本(%)
	 */
	private BigDecimal hedgeCostRate;

	/**
	 * 避險資金成本之利率指標
	 */
	private String rateIndex;

	/**
	 * 避利率指標加減碼(%)
	 */
	private String spread;

	/**
	 * 稅率
	 */
	private BigDecimal taxRate;

	/**
	 * 報酬率(%)
	 */
	private BigDecimal returnRate;

}

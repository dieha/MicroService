package com.redhat.lab.infrastructure.repository.po;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "CAHNNEL_PRODUCT")
public class ChannelProductPo {

	@Id
	@Column(name = "ID")
	private int id;

	@ManyToOne
	@JoinColumn(name = "CHANNEL_ID")
	private ChannelPo channelPo;

	@ManyToOne
	@JoinColumn(name = "PRODUCT_ID")
	private ProductPo productPo;
	
}

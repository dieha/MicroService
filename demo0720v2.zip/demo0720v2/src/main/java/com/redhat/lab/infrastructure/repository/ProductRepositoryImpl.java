package com.redhat.lab.infrastructure.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.redhat.lab.core.product.entity.ProductDo;
import com.redhat.lab.core.product.repository.ProductRepository;
import com.redhat.lab.infrastructure.common.api.MockServiceAapter;
import com.redhat.lab.infrastructure.repository.mapper.ChannelProductDao;
import com.redhat.lab.infrastructure.repository.mapper.ChannelProductDefaultParamDao;
import com.redhat.lab.infrastructure.repository.mapper.ProductDao;

@Service
public class ProductRepositoryImpl implements ProductRepository {

	@Autowired
	ProductDao productDao;

	@Autowired
	ChannelProductDao channelProductDao;
	
	@Autowired
	ChannelProductDefaultParamDao channelProductDefaultParamDao;
	
	@Autowired
	MockServiceAapter mockServiceAapter;

	@Override
	public List<ProductDo> findByChannelId(String channelId) {
		
		return null;
	}

}

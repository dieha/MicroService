package com.redhat.lab.core.bankcode.repository;

import java.util.List;

import com.redhat.lab.core.bankcode.entity.BankCodeVo;

public interface BankCodeRepository {

	public List<BankCodeVo> findAll();

	public BankCodeVo save(BankCodeVo bankCodeVo);

}

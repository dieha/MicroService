package com.redhat.lab.interfaces.dto;

import java.util.Objects;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 通路商品
 */
@ApiModel(description = "通路商品")
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2022-07-19T10:43:55.467923+08:00[Asia/Taipei]")
public class ChannelProductRequest   {
  @JsonProperty("ProductId")
  private String productId;

  @JsonProperty("ProductName")
  private String productName;

  @JsonProperty("ProductType")
  private String productType;

  @JsonProperty("ChannelID")
  private String channelID;

  public ChannelProductRequest productId(String productId) {
    this.productId = productId;
    return this;
  }

  /**
   * 商品代號
   * @return productId
  */
  @ApiModelProperty(value = "商品代號")


  public String getProductId() {
    return productId;
  }

  public void setProductId(String productId) {
    this.productId = productId;
  }

  public ChannelProductRequest productName(String productName) {
    this.productName = productName;
    return this;
  }

  /**
   * 商品名稱
   * @return productName
  */
  @ApiModelProperty(value = "商品名稱")


  public String getProductName() {
    return productName;
  }

  public void setProductName(String productName) {
    this.productName = productName;
  }

  public ChannelProductRequest productType(String productType) {
    this.productType = productType;
    return this;
  }

  /**
   * 商品類別
   * @return productType
  */
  @ApiModelProperty(value = "商品類別")


  public String getProductType() {
    return productType;
  }

  public void setProductType(String productType) {
    this.productType = productType;
  }

  public ChannelProductRequest channelID(String channelID) {
    this.channelID = channelID;
    return this;
  }

  /**
   * 通路代號
   * @return channelID
  */
  @ApiModelProperty(required = true, value = "通路代號")
  @NotNull


  public String getChannelID() {
    return channelID;
  }

  public void setChannelID(String channelID) {
    this.channelID = channelID;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ChannelProductRequest channelProductRequest = (ChannelProductRequest) o;
    return Objects.equals(this.productId, channelProductRequest.productId) &&
        Objects.equals(this.productName, channelProductRequest.productName) &&
        Objects.equals(this.productType, channelProductRequest.productType) &&
        Objects.equals(this.channelID, channelProductRequest.channelID);
  }

  @Override
  public int hashCode() {
    return Objects.hash(productId, productName, productType, channelID);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ChannelProductRequest {\n");
    
    sb.append("    productId: ").append(toIndentedString(productId)).append("\n");
    sb.append("    productName: ").append(toIndentedString(productName)).append("\n");
    sb.append("    productType: ").append(toIndentedString(productType)).append("\n");
    sb.append("    channelID: ").append(toIndentedString(channelID)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

